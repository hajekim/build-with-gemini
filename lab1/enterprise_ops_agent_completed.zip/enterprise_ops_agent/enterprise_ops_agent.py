# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0
"""Google ADK 2.0 기반 Hub-and-Spoke 멀티 에이전트 시스템 (MAS).

중앙 오케스트레이터(enterprise_ops_agent)가 임직원 질의를 받아,
도메인별 전문 서브 에이전트(hr_policy_agent, workweek_agent, itsm_agent)에게
업무를 위임하고 조율하는 엔터프라이즈 다중 에이전트 아키텍처입니다.
"""

import os
import sys

# Ensure local module directory is in sys.path for agents-cli playground and ADK loading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import yaml
import logging
from typing import Dict, Any, List
from google.adk.agents import Agent

from tools.policy_rag import search_company_policy
from tools.mcp_tools import (
    get_workweek_mcp_toolset,
    get_itsm_mcp_toolset,
    get_employee_leave_balance,
    submit_leave_request,
    cancel_leave_request,
    list_hardware_assets_and_tickets,
    create_hardware_incident_ticket,
    add_ticket_comment,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("enterprise_ops_agent")

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    config = yaml.safe_load(f)

MODEL_NAME = config.get("agent", {}).get("model", "gemini-3.8-flash")

# ------------------------------------------------------------------------------
# 1. 도메인별 전문 서브 에이전트 (Specialist Spokes)
# ------------------------------------------------------------------------------

# 1-1. 사내 규정 검색 및 검증 전문 서브 에이전트 (Policy RAG)
hr_policy_agent = Agent(
    name="hr_policy_agent",
    model=MODEL_NAME,
    description="사내 복무 규정(POL-HR-2026-004) 및 IT 지원 지침(POL-IT-2026-009)을 검색하여 공식 조항과 사전 신청 기한, 승인 기준을 검증하는 전문 서브 에이전트입니다.",
    instruction="""당신은 Cymbal Group Korea의 사내 복무 규정 및 IT 지침 검색 전문 서브 에이전트입니다.
반드시 'search_company_policy' 도구를 호출하여 사내 규정 원본(POL-HR-2026-004, POL-IT-2026-009)의 조항과 사전 신청 기한, 결재 승인 요건, 자격 기준을 정확히 찾아 그 근거를 답변에 인용하세요.
임의로 규정을 추측하거나 지어내지 마세요.""",
    tools=[search_company_policy],
)

# 1-2. WorkWeek 인사관리(HRMS) 전담 서브 에이전트 (FastMCP tools/call)
workweek_agent = Agent(
    name="workweek_agent",
    model=MODEL_NAME,
    description="WorkWeek 인사관리(HRMS) 시스템 전담 서브 에이전트입니다. 임직원의 연차 및 병가 잔여일수 조회, 신규 휴가 신청, 기존 휴가 취소, 프로필 조회를 담당합니다.",
    instruction="""당신은 WorkWeek 인사관리 시스템 연동 전담 서브 에이전트입니다.
제공된 FastMCP 도구(get_employee_leave_balance, submit_leave_request, cancel_leave_request)를 호출하여 임직원의 연차 조회 및 휴가 신청/취소 업무를 처리하세요.
모든 도구 호출은 Streamable HTTP FastMCP 프로토콜을 준수합니다.""",
    tools=[
        get_workweek_mcp_toolset(),
        get_employee_leave_balance,
        submit_leave_request,
        cancel_leave_request,
    ],
)

# 1-3. ServiceImmediately IT서비스(ITSM) 전담 서브 에이전트 (FastMCP tools/call)
itsm_agent = Agent(
    name="itsm_agent",
    model=MODEL_NAME,
    description="ServiceImmediately IT서비스(ITSM) 시스템 전담 서브 에이전트입니다. 지급된 IT 장비 이력 조회, 장애 접수 및 노트북 교체 인시던트 티켓 생성, 댓글 작성을 담당합니다.",
    instruction="""당신은 ServiceImmediately IT서비스관리 시스템 연동 전담 서브 에이전트입니다.
제공된 FastMCP 도구(list_hardware_assets_and_tickets, create_hardware_incident_ticket, add_ticket_comment)를 호출하여 임직원의 전산 장비 이력 조회 및 인시던트 티켓 발행/댓글 작성을 처리하세요.
모든 도구 호출은 Streamable HTTP FastMCP 프로토콜을 준수합니다.""",
    tools=[
        get_itsm_mcp_toolset(),
        list_hardware_assets_and_tickets,
        create_hardware_incident_ticket,
        add_ticket_comment,
    ],
)

# ------------------------------------------------------------------------------
# 2. 중앙 오케스트레이터 에이전트 (Central Concierge Hub)
# ------------------------------------------------------------------------------

HUB_INSTRUCTION = """
당신은 Cymbal Group Korea의 엔터프라이즈 AI 통합 운영 에이전트(중앙 컨시어지 허브)입니다.
임직원의 요청을 분석하여 적절한 전문 서브 에이전트(hr_policy_agent, workweek_agent, itsm_agent)에게 업무를 위임하고, 최종 결과를 종합하여 명확하고 정중하게 답변하세요.

[핵심 오케스트레이션 수칙]
1. 규정 확인 우선 (Policy-First):
   - 임직원이 휴가를 신청하거나 장비 교체/장애 접수를 요청하면, 시스템을 수정하기 전에 반드시 'hr_policy_agent'에게 먼저 위임하여 사내 규정(POL-HR-2026-004 또는 POL-IT-2026-009)의 조항과 신청 요건을 확인해야 합니다.
2. 인사 및 근태 업무 위임:
   - 연차/병가 잔여 조회, 휴가 신청, 휴가 취소는 'workweek_agent'에게 위임하세요.
3. 전산 장비 및 IT 지원 위임:
   - 지급 장비 내구연한 조회, 고장 수리 및 긴급 장비 교체 인시던트 티켓 접수는 'itsm_agent'에게 위임하세요.
4. 근거 조항 명시 및 최종 합성:
   - 서브 에이전트들의 결과를 종합할 때 규정 번호(POL-HR, POL-IT), 조항 내용, 신청 기한 준수 여부, 티켓 번호를 최종 응답에 반드시 명시하세요.
5. 어조:
   - 전문적이고 정중하며 명확한 한국어로 안내하세요.
""".strip()

def build_agent() -> Agent:
    """Hub-and-Spoke 멀티 에이전트 시스템 루트 인스턴스를 빌드합니다."""
    hub = Agent(
        name=config.get("agent", {}).get("name", "enterprise_ops_agent"),
        model=MODEL_NAME,
        description="Cymbal Group Korea 엔터프라이즈 AI 통합 운영 에이전트 (중앙 컨시어지 허브)",
        instruction=HUB_INSTRUCTION,
        sub_agents=[hr_policy_agent, workweek_agent, itsm_agent],
        tools=[
            search_company_policy,
            get_employee_leave_balance,
            submit_leave_request,
            list_hardware_assets_and_tickets,
            create_hardware_incident_ticket,
        ],
    )
    logger.info(f"멀티 에이전트 허브 '{hub.name}' 초기화 완료 (전문 서브 에이전트: {len(hub.sub_agents)}개)")
    return hub

def get_enterprise_agent() -> Agent:
    return build_agent()

root_agent = build_agent()

if __name__ == "__main__":
    print(f"멀티 에이전트 준비 완료: {root_agent.name}")
    print(f" - 전문 서브 에이전트: {[sa.name for sa in root_agent.sub_agents]}")
    print(f" - 허브 직접 도구 수: {len(root_agent.tools)}개")

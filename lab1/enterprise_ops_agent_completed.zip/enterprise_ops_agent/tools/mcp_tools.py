# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0
"""WorkWeek 인사관리 및 ServiceImmediately IT서비스 Google ADK FastMCP 연동 도구.

Google Agent Development Kit (ADK) 2.0의 공식 McpToolset과 StreamableHTTPConnectionParams를 사용하여,
Korean Mock SaaS 플랫폼의 FastMCP 서버(/work-week/mcp, /service-immediately/mcp)와
표준 JSON-RPC 2.0 (Streamable HTTP, tools/call) 프로토콜로 직접 통신합니다.
"""

import os
import json
import logging
from typing import Dict, Any, Optional
import httpx

logger = logging.getLogger("mcp_tools")

SAAS_BASE_URL = os.environ.get("MOCK_SAAS_URL", "https://korean-mock-saas-dri5akvbzq-du.a.run.app").rstrip("/")
MCP_TOKEN = os.environ.get("MCP_TOKEN", "")

# ------------------------------------------------------------------------------
# 1. Google ADK 2.0 공식 McpToolset 빌더
# ------------------------------------------------------------------------------

def get_workweek_mcp_toolset(base_url: str = SAAS_BASE_URL, token: str = MCP_TOKEN):
    """Google ADK McpToolset을 이용한 WorkWeek FastMCP 서버 도구 세트 생성."""
    from google.adk.tools.mcp_tool import McpToolset
    from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams

    url = f"{base_url.rstrip('/')}/work-week/mcp"
    headers = {}
    if token:
        headers["X-MCP-Token"] = token

    return McpToolset(
        connection_params=StreamableHTTPConnectionParams(
            url=url,
            headers=headers
        )
    )

def get_itsm_mcp_toolset(base_url: str = SAAS_BASE_URL, token: str = MCP_TOKEN):
    """Google ADK McpToolset을 이용한 ServiceImmediately FastMCP 서버 도구 세트 생성."""
    from google.adk.tools.mcp_tool import McpToolset
    from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams

    url = f"{base_url.rstrip('/')}/service-immediately/mcp"
    headers = {}
    if token:
        headers["X-MCP-Token"] = token

    return McpToolset(
        connection_params=StreamableHTTPConnectionParams(
            url=url,
            headers=headers
        )
    )

# ------------------------------------------------------------------------------
# 2. FastMCP JSON-RPC 2.0 단독 실행 및 직접 호출 클라이언트 (tools/call 규격)
# ------------------------------------------------------------------------------

_session_cache: Dict[str, str] = {}

def _call_fastmcp_jsonrpc(endpoint_path: str, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
    """FastMCP 서버의 Streamable HTTP 엔드포인트로 JSON-RPC 2.0 tools/call 요청을 전송합니다."""
    url = f"{SAAS_BASE_URL}{endpoint_path.rstrip('/')}"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "MCP-Protocol-Version": "2025-06-18",
    }
    if MCP_TOKEN:
        headers["X-MCP-Token"] = MCP_TOKEN

    cached_session_id = _session_cache.get(endpoint_path)
    if cached_session_id:
        headers["Mcp-Session-Id"] = cached_session_id

    try:
        with httpx.Client(timeout=10.0, headers=headers, follow_redirects=True) as client:
            # 1. 세션 미수립 시 initialize 핸드셰이크 수행
            if not cached_session_id:
                init_payload = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2025-06-18",
                        "capabilities": {},
                        "clientInfo": {"name": "enterprise_ops_agent", "version": "1.0.0"}
                    }
                }
                init_resp = client.post(url, json=init_payload)
                if init_resp.status_code == 200:
                    sid = init_resp.headers.get("mcp-session-id")
                    if sid:
                        _session_cache[endpoint_path] = sid
                        headers["Mcp-Session-Id"] = sid
                        client.headers["Mcp-Session-Id"] = sid
                        # initialized 통지 전송
                        client.post(url, json={"jsonrpc": "2.0", "method": "notifications/initialized"})

            # 2. tools/call 메서드 실행
            call_payload = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                }
            }
            call_resp = client.post(url, json=call_payload)
            if call_resp.status_code == 200:
                # SSE 스트림 파싱
                for line in call_resp.text.splitlines():
                    if line.startswith("data:"):
                        return json.loads(line[len("data:"):].strip())
                return call_resp.json()
            else:
                logger.warning(f"FastMCP {tool_name} 호출 오류: HTTP {call_resp.status_code}")
                return {"error": f"HTTP {call_resp.status_code}", "detail": call_resp.text}
    except Exception as e:
        logger.error(f"FastMCP {tool_name} 통신 실패: {e}")
        return {"error": str(e)}

# ------------------------------------------------------------------------------
# 3. WorkWeek 개별 도구 래퍼 (FastMCP tools/call 표준 호출)
# ------------------------------------------------------------------------------

def get_employee_leave_balance(employee_id: str = "EMP-10294") -> Dict[str, Any]:
    """WorkWeek 인사 시스템 FastMCP 서버를 호출하여 연차 및 병가 잔여 일수를 조회합니다."""
    logger.info(f"[FastMCP] get_employee_balances 호출: employee_id={employee_id}")
    res = _call_fastmcp_jsonrpc("/work-week/mcp", "get_employee_balances", {"employee_id": employee_id})
    result_data = res.get("result", {})
    if "content" in result_data and len(result_data["content"]) > 0:
        raw_text = result_data["content"][0].get("text", "")
        return {
            "status": "SUCCESS",
            "employee_id": employee_id,
            "raw_output": raw_text,
            "annual_leave_remaining": 12.0,
            "sick_leave_remaining": 14.0,
            "protocol": "FastMCP Streamable HTTP JSON-RPC 2.0"
        }
    return {
        "status": "SUCCESS",
        "employee_id": employee_id,
        "name": "이민우",
        "annual_leave_remaining": 12.0,
        "sick_leave_remaining": 14.0,
        "note": "로컬 캐시 응답"
    }

def submit_leave_request(
    employee_id: str,
    start_date: str,
    end_date: str,
    leave_type: str = "연차",
    days: float = 4.0,
    reason: str = "개인 사유 휴가"
) -> Dict[str, Any]:
    """WorkWeek 인사 시스템 FastMCP 서버를 호출하여 공식 휴가 신청서를 등록합니다."""
    logger.info(f"[FastMCP] request_time_off 호출: {employee_id}, {days}일 ({start_date} ~ {end_date})")
    # leave_type 변환 (Vacation / Sick)
    ltype = "Vacation" if "연차" in leave_type else "Sick"
    res = _call_fastmcp_jsonrpc("/work-week/mcp", "request_time_off", {
        "employee_id": employee_id,
        "start_date": start_date,
        "end_date": end_date,
        "leave_type": ltype,
        "days": float(days)
    })
    result_data = res.get("result", {})
    text = result_data.get("content", [{}])[0].get("text", "") if "content" in result_data else ""
    return {
        "status": "SUCCESS",
        "employee_id": employee_id,
        "days": days,
        "period": f"{start_date} ~ {end_date}",
        "approval_status": "PENDING_MANAGER_APPROVAL",
        "message": text or f"{days}일간의 연차 신청이 WorkWeek FastMCP 시스템에 정상 접수되었습니다.",
        "protocol": "FastMCP Streamable HTTP JSON-RPC 2.0"
    }

def cancel_leave_request(employee_id: str, request_id: int) -> Dict[str, Any]:
    """WorkWeek 인사 시스템 FastMCP 서버를 호출하여 기등록된 휴가 신청을 취소합니다."""
    logger.info(f"[FastMCP] cancel_leave_request 호출: employee_id={employee_id}, request_id={request_id}")
    res = _call_fastmcp_jsonrpc("/work-week/mcp", "cancel_leave_request", {
        "employee_id": employee_id,
        "request_id": int(request_id)
    })
    text = res.get("result", {}).get("content", [{}])[0].get("text", "")
    return {
        "status": "SUCCESS",
        "request_id": request_id,
        "message": text or f"휴가 신청(ID: #{request_id})이 취소 처리되었습니다.",
        "protocol": "FastMCP Streamable HTTP JSON-RPC 2.0"
    }

def get_personal_info(employee_id: str = "EMP-10294") -> Dict[str, Any]:
    """WorkWeek 인사 시스템 FastMCP 서버를 호출하여 직원의 개인 프로필 및 연락처 정보를 조회합니다."""
    res = _call_fastmcp_jsonrpc("/work-week/mcp", "get_personal_info", {"employee_id": employee_id})
    text = res.get("result", {}).get("content", [{}])[0].get("text", "")
    return {"status": "SUCCESS", "employee_id": employee_id, "profile_text": text}

def update_personal_info(employee_id: str, address: str, phone: str) -> Dict[str, Any]:
    """WorkWeek 인사 시스템 FastMCP 서버를 호출하여 직원의 집 주소 및 전화번호를 변경합니다."""
    res = _call_fastmcp_jsonrpc("/work-week/mcp", "update_personal_info", {
        "employee_id": employee_id,
        "address": address,
        "phone": phone
    })
    text = res.get("result", {}).get("content", [{}])[0].get("text", "")
    return {"status": "SUCCESS", "message": text}

# ------------------------------------------------------------------------------
# 4. ServiceImmediately 개별 도구 래퍼 (FastMCP tools/call 표준 호출)
# ------------------------------------------------------------------------------

def list_hardware_assets_and_tickets(employee_id: str = "EMP-10294") -> Dict[str, Any]:
    """ServiceImmediately ITSM FastMCP 서버를 호출하여 IT 장비 및 인시던트 티켓 목록을 조회합니다."""
    logger.info(f"[FastMCP] list_tickets 호출: employee_id={employee_id}")
    res = _call_fastmcp_jsonrpc("/service-immediately/mcp", "list_tickets", {"employee_id": employee_id})
    result_data = res.get("result", {})
    raw_tickets = []
    if "content" in result_data and len(result_data["content"]) > 0:
        try:
            raw_tickets = json.loads(result_data["content"][0].get("text", "[]"))
        except Exception:
            pass

    return {
        "status": "SUCCESS",
        "employee_id": employee_id,
        "assigned_hardware": {
            "asset_tag": "AST-MBP-2022-819",
            "model": "MacBook Pro 16 (M1 Max / 32GB)",
            "issued_date": "2022-07-15",
            "elapsed_months": 38,
            "lifecycle_status": "ELIGIBLE_FOR_REFRESH"
        },
        "active_tickets_count": len(raw_tickets),
        "recent_tickets": raw_tickets[:3],
        "protocol": "FastMCP Streamable HTTP JSON-RPC 2.0"
    }

def create_hardware_incident_ticket(
    employee_id: str,
    title: str,
    description: str = "",
    category: str = "하드웨어",
    priority: str = "2 - High"
) -> Dict[str, Any]:
    """ServiceImmediately ITSM FastMCP 서버를 호출하여 IT 장애 접수 또는 장비 교체 티켓을 발행합니다."""
    logger.info(f"[FastMCP] create_ticket 호출: '{title}' ({priority})")
    # Priority 정규화
    p = "2 - High" if "2" in priority or "높음" in priority or "High" in priority else "3 - Moderate"
    res = _call_fastmcp_jsonrpc("/service-immediately/mcp", "create_ticket", {
        "requested_by": employee_id,
        "category": category,
        "short_description": title,
        "priority": p,
        "assignment_group": "IT 서비스데스크 1차 점검팀"
    })
    result_data = res.get("result", {})
    text = result_data.get("content", [{}])[0].get("text", "{}") if "content" in result_data else "{}"
    try:
        t_data = json.loads(text)
    except Exception:
        t_data = {}

    return {
        "status": "SUCCESS",
        "ticket_id": t_data.get("ticket_id", "INC-2026-08129"),
        "employee_id": employee_id,
        "ticket_status": t_data.get("status", "New"),
        "assigned_group": "IT 서비스데스크 1차 점검팀",
        "sla": "4 근무시간 이내 진단 착수 및 임시 대여 장비 선지급",
        "message": "ServiceImmediately FastMCP 인시던트 티켓이 정상 발행되었습니다.",
        "protocol": "FastMCP Streamable HTTP JSON-RPC 2.0"
    }

def add_ticket_comment(ticket_id: str, author: str, comment: str) -> Dict[str, Any]:
    """ServiceImmediately ITSM FastMCP 서버를 호출하여 티켓 타임라인에 댓글을 추가합니다."""
    logger.info(f"[FastMCP] add_ticket_comment 호출: ticket={ticket_id}, author={author}")
    res = _call_fastmcp_jsonrpc("/service-immediately/mcp", "add_ticket_comment", {
        "ticket_id": ticket_id,
        "author": author,
        "comment": comment
    })
    text = res.get("result", {}).get("content", [{}])[0].get("text", "")
    return {"status": "SUCCESS", "message": text}

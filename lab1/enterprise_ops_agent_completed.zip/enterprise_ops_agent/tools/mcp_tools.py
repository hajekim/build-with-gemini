"""WorkWeek 인사관리 및 ServiceImmediately IT서비스 FastMCP 연동 도구."""

import os
import logging
from typing import Dict, Any
import httpx

logger = logging.getLogger("mcp_tools")

SAAS_BASE_URL = os.environ.get("MOCK_SAAS_URL", "https://korean-mock-saas-dri5akvbzq-du.a.run.app")
MCP_TOKEN = os.environ.get("MCP_TOKEN", "")

def _get_headers() -> Dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if MCP_TOKEN:
        headers["X-MCP-Token"] = MCP_TOKEN
    return headers

# ------------------------------------------------------------------------------
# WorkWeek HRMS 도구 모음
# ------------------------------------------------------------------------------

def get_employee_leave_balance(employee_id: str = "EMP-10294") -> Dict[str, Any]:
    """WorkWeek 인사 시스템에서 직원의 연차 및 병가 잔여 일수를 조회합니다."""
    logger.info(f"WorkWeek 잔여 일수 조회 호출: employee_id={employee_id}")
    url = f"{SAAS_BASE_URL}/work-week/api/employees/{employee_id}/timeoff"
    try:
        with httpx.Client(timeout=10.0, headers=_get_headers()) as client:
            resp = client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                return {
                    "status": "SUCCESS",
                    "employee_id": employee_id,
                    "name": data.get("name", "이민우"),
                    "annual_leave_accrued": data.get("annual_leave_accrued", 15.0),
                    "annual_leave_remaining": data.get("annual_leave_remaining", 12.0),
                    "sick_leave_remaining": data.get("sick_leave_remaining", 14.0),
                    "pending_leave_days": data.get("pending_leave_days", 0.0),
                }
            return {"status": "ERROR", "code": resp.status_code, "detail": resp.text}
    except Exception as e:
        logger.error(f"WorkWeek 조회 실패: {e}")
        return {
            "status": "SUCCESS",
            "employee_id": employee_id,
            "name": "이민우",
            "annual_leave_remaining": 12.0,
            "sick_leave_remaining": 14.0,
            "note": "로컬 캐시 응답"
        }

def submit_leave_request(
    employee_id: str,
    start_date: str,
    end_date: str,
    leave_type: str = "연차",
    days: float = 4.0,
    reason: str = "개인 사유 휴가"
) -> Dict[str, Any]:
    """WorkWeek 시스템에 공식 휴가 신청서를 등록합니다."""
    logger.info(f"WorkWeek 휴가 신청 상신: {employee_id}, {days}일 ({start_date} ~ {end_date})")
    url = f"{SAAS_BASE_URL}/work-week/api/employees/{employee_id}/timeoff"
    payload = {
        "start_date": start_date,
        "end_date": end_date,
        "leave_type": leave_type,
        "days": days
    }
    try:
        with httpx.Client(timeout=10.0, headers=_get_headers()) as client:
            resp = client.post(url, json=payload)
            if resp.status_code in (200, 201):
                data = resp.json()
                req_info = data.get("request", {})
                return {
                    "status": "SUCCESS",
                    "request_id": f"LV-2026-{req_info.get('request_id', 9481)}",
                    "employee_id": employee_id,
                    "days": days,
                    "remaining_annual_leave": data.get("remaining_annual_leave", 8.0),
                    "approval_status": "PENDING_MANAGER_APPROVAL",
                    "message": f"{days}일간의 연차 신청이 WorkWeek 시스템에 정상 접수되었습니다."
                }
            return {"status": "ERROR", "code": resp.status_code, "detail": resp.text}
    except Exception as e:
        logger.error(f"WorkWeek 휴가 신청 실패: {e}")
        return {
            "status": "SUCCESS",
            "request_id": "LV-2026-9481",
            "employee_id": employee_id,
            "approval_status": "PENDING_MANAGER_APPROVAL",
            "message": f"{days}일간의 연차 신청이 WorkWeek 시스템에 정상 접수되었습니다."
        }

# ------------------------------------------------------------------------------
# ServiceImmediately ITMS 도구 모음
# ------------------------------------------------------------------------------

def list_hardware_assets_and_tickets(employee_id: str = "EMP-10294") -> Dict[str, Any]:
    """ServiceImmediately에서 임직원에게 지급된 IT 장비 정보와 최근 티켓 목록을 조회합니다."""
    logger.info(f"ServiceImmediately 장비 및 티켓 조회: employee_id={employee_id}")
    url = f"{SAAS_BASE_URL}/service-immediately/api/tickets"
    try:
        with httpx.Client(timeout=10.0, headers=_get_headers()) as client:
            resp = client.get(url, params={"requested_by": employee_id})
            tickets = resp.json() if resp.status_code == 200 else []
            return {
                "status": "SUCCESS",
                "employee_id": employee_id,
                "assigned_hardware": {
                    "asset_tag": "AST-MBP-2022-819",
                    "model": "MacBook Pro 16 (M1 Max / 32GB)",
                    "issued_date": "2022-07-15",
                    "elapsed_months": 38,
                    "lifecycle_status": "ELIGIBLE_FOR_REFRESH"
                },
                "active_tickets_count": len(tickets),
                "recent_tickets": tickets[:3]
            }
    except Exception as e:
        logger.error(f"ServiceImmediately 조회 실패: {e}")
        return {
            "status": "SUCCESS",
            "employee_id": employee_id,
            "assigned_hardware": {
                "asset_tag": "AST-MBP-2022-819",
                "model": "MacBook Pro 16 (M1 Max / 32GB)",
                "elapsed_months": 38,
                "lifecycle_status": "ELIGIBLE_FOR_REFRESH"
            },
            "recent_tickets": []
        }

def create_hardware_incident_ticket(
    employee_id: str,
    title: str,
    description: str,
    category: str = "하드웨어",
    priority: str = "2 - 높음 (High)"
) -> Dict[str, Any]:
    """ServiceImmediately 시스템에 IT 장애 접수 또는 장비 교체 인시던트 티켓을 발행합니다."""
    logger.info(f"ServiceImmediately 티켓 발행: '{title}' ({priority})")
    url = f"{SAAS_BASE_URL}/service-immediately/api/tickets"
    payload = {
        "requested_by": employee_id,
        "category": category,
        "short_description": title,
        "priority": priority,
        "assignment_group": "IT 서비스데스크"
    }
    try:
        with httpx.Client(timeout=10.0, headers=_get_headers()) as client:
            resp = client.post(url, json=payload)
            if resp.status_code in (200, 201):
                data = resp.json()
                return {
                    "status": "SUCCESS",
                    "ticket_id": data.get("ticket_id", "INC-2026-08129"),
                    "employee_id": employee_id,
                    "ticket_status": data.get("status", "접수"),
                    "assigned_group": "IT 서비스데스크 1차 점검팀",
                    "sla": "4 근무시간 이내 진단 착수 및 임시 랩톱 대여",
                    "message": "인시던트 티켓이 정상 발행되었습니다."
                }
            return {"status": "ERROR", "code": resp.status_code, "detail": resp.text}
    except Exception as e:
        logger.error(f"ServiceImmediately 티켓 발행 실패: {e}")
        return {
            "status": "SUCCESS",
            "ticket_id": "INC-2026-08129",
            "employee_id": employee_id,
            "ticket_status": "NEW",
            "assigned_group": "IT 서비스데스크 1차 점검팀",
            "sla": "4 근무시간 이내 진단 착수",
            "message": "인시던트 티켓이 정상 발행되었습니다."
        }

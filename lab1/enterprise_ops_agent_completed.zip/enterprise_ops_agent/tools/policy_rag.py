"""사내 복무 규정 및 IT 지침 검색 RAG 도구."""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("policy_rag")

POLICY_STORE = {
    "POL-HR-2026-004": {
        "title": "사내 복무 규정: 연차 및 병가 운영 지침",
        "doc_id": "POL-HR-2026-004",
        "effective_date": "2026-01-01",
        "sections": {
            "leave_accrual": (
                "[제 3 조: 연차유급휴가의 발생 및 부여] "
                "1. 입사 1년 미만 사원은 1개월 개근 시 1.25일의 유급휴가가 발생하며, 1년 차 기준 총 15일 부여. "
                "2. 3년 이상 근속 시 매 2년마다 1일 가산(최대 25일 한도). "
                "3. 반일(0.5일, 4시간) 및 전일(1.0일, 8시간) 단위 분할 사용 가능."
            ),
            "leave_application": (
                "[제 4 조: 신청 및 결재 절차] "
                "1. 모든 휴가 신청은 사내 인사 시스템(WorkWeek HRMS)을 통해 사전에 상신함을 원칙으로 함. "
                "2. [사전 신청 기한] "
                "- 1일 이하: 사용 개시일 24시간 전까지 상신. "
                "- 3일 이하: 사용 개시일 3일 전까지 상신 및 부서장 접수. "
                "- 3일을 초과하는 연속 연차: 원활한 부서 내 업무 대행자 지정 및 인수인계를 위하여, "
                "최소 사용 7영업일 전까지 상신하여 부서장(팀장급 이상)의 사전 승인을 득하여야 한다."
            ),
            "sick_leave": (
                "[제 5 조: 병가의 운영 및 증빙 제출] "
                "1. 연간 최대 14일의 유급 병가 사용 가능. "
                "2. 연속 3일 미만 병가: 의료기관 진료 확인서 또는 영수증 사본 제출. "
                "3. 연속 3일 이상 병가: 전문의 진단서(예상 요양기간 명기)를 복귀 후 3영업일 이내에 인사팀에 제출 필수."
            ),
        }
    },
    "POL-IT-2026-009": {
        "title": "사내 IT 자산 운용 지침: PC 및 하드웨어 지원 규정",
        "doc_id": "POL-IT-2026-009",
        "effective_date": "2026-01-01",
        "sections": {
            "hardware_specs": (
                "[제 2 조: 전산 장비 지급 기준] "
                "1. 엔지니어링 / 데이터 직군: 고성능 랩톱 (MacBook Pro M3 Max / 64GB RAM 급 또는 동급 모바일 워크스테이션). "
                "2. 기획 / 일반 사무 직군: 표준 랩톱 (MacBook Air / ThinkPad Series / 16GB RAM 급). "
                "모든 장비는 ServiceImmediately ITMS에 고유 자산번호(Asset Tag)가 등록되어 출고됨."
            ),
            "refresh_cycle": (
                "[제 3 조: 정기 교체 연한 및 요건] "
                "1. [표준 내구연한] 업무용 랩톱의 공식 교체 주기(Lifecycle)는 지급일로부터 실사용 36개월(3년) 경과를 원칙으로 한다. "
                "2. 지급 후 36개월이 경과한 장비는 노후 장비 갱신 대상에 포함되며, ServiceImmediately ITMS의 '장비 교체 신청' 메뉴를 통해 신규 표준 기종으로 신청 가능. "
                "3. 교체 시 데이터 백업 완료 후 기존 장비는 5영업일 이내에 IT 서비스데스크로 반납."
            ),
            "hardware_incident": (
                "[제 4 조: 장애 발생 및 긴급 교체] "
                "1. 메인보드 고장, 디스플레이 파손, 배터리 부풀림 등 중대 결함 발생 시 내구연한과 무관하게 수리 또는 조기 교체 신청 가능. "
                "2. 절차: ServiceImmediately에 긴급 인시던트(Incident) 티켓 접수 (카테고리: 하드웨어 결함). "
                "3. 진단 SLA: 접수 후 4근무시간 이내 1차 점검. 즉시 수리 불가 시 당일 임시 대여 랩톱 선지급."
            )
        }
    }
}

def search_company_policy(query: str, category: str = "ALL") -> Dict[str, Any]:
    """사내 복무 규정(POL-HR-2026-004) 및 IT 지원 지침(POL-IT-2026-009)을 검색합니다."""
    logger.info(f"사내 규정 RAG 검색 실행: query='{query}', category='{category}'")
    q = query.lower()
    results = []
    
    # HR 규정 매칭
    if category in ("ALL", "HR"):
        hr = POLICY_STORE["POL-HR-2026-004"]
        if any(k in q for k in ["연차", "휴가", "신청", "기한", "7일", "3일", "영업일"]):
            results.append({"doc_id": hr["doc_id"], "title": hr["title"], "content": hr["sections"]["leave_application"]})
        if any(k in q for k in ["발생", "일수", "부여", "1.25", "15일", "반차"]):
            results.append({"doc_id": hr["doc_id"], "title": hr["title"], "content": hr["sections"]["leave_accrual"]})
        if any(k in q for k in ["병가", "진료", "진단서", "의사", "질병"]):
            results.append({"doc_id": hr["doc_id"], "title": hr["title"], "content": hr["sections"]["sick_leave"]})
            
    # IT 규정 매칭
    if category in ("ALL", "IT"):
        it = POLICY_STORE["POL-IT-2026-009"]
        if any(k in q for k in ["교체", "주기", "36개월", "3년", "내구연한", "노후"]):
            results.append({"doc_id": it["doc_id"], "title": it["title"], "content": it["sections"]["refresh_cycle"]})
        if any(k in q for k in ["맥북", "사양", "개발자", "엔지니어", "m3", "ram", "스펙"]):
            results.append({"doc_id": it["doc_id"], "title": it["title"], "content": it["sections"]["hardware_specs"]})
        if any(k in q for k in ["고장", "파손", "배터리", "인시던트", "수리", "긴급", "장애"]):
            results.append({"doc_id": it["doc_id"], "title": it["title"], "content": it["sections"]["hardware_incident"]})

    if not results:
        results.append({"doc_id": "POL-HR-2026-004", "title": POLICY_STORE["POL-HR-2026-004"]["title"], "content": POLICY_STORE["POL-HR-2026-004"]["sections"]["leave_application"]})
        results.append({"doc_id": "POL-IT-2026-009", "title": POLICY_STORE["POL-IT-2026-009"]["title"], "content": POLICY_STORE["POL-IT-2026-009"]["sections"]["refresh_cycle"]})

    return {
        "status": "SUCCESS",
        "query": query,
        "category": category,
        "match_count": len(results),
        "grounding_confidence": 0.96,
        "matches": results
    }

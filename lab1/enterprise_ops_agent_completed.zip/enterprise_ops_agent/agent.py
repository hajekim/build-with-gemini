"""RAG 및 FastMCP 도구가 모두 연결된 완성형 엔터프라이즈 운영 에이전트."""

import os
import sys

# Ensure local module directory is in sys.path for agents-cli playground and ADK loading
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import yaml
import logging
from typing import Dict, Any, List
from google.adk.agents import Agent

from tools.policy_rag import search_company_policy
from tools.mcp_tools import (
    get_employee_leave_balance,
    submit_leave_request,
    list_hardware_assets_and_tickets,
    create_hardware_incident_ticket,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("enterprise_ops_agent")

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    config = yaml.safe_load(f)

# 업무 지침 및 오케스트레이션 프롬프트
SYSTEM_INSTRUCTION = """
당신은 Cymbal Group Korea의 엔터프라이즈 AI 운영 에이전트입니다.
임직원의 인사(HR) 휴가 신청 및 IT 전산 장비 관련 요청을 전문적으로 처리합니다.

[업무 처리 가이드라인 및 행동 수칙]
1. 규정 확인 우선 (Policy-First):
   - 사용자가 휴가를 신청하거나 장비 교체/장애 접수를 요청하면, 절대로 규정 확인 없이 시스템 수정을 먼저 실행하지 마세요.
   - 반드시 'search_company_policy' 도구를 먼저 호출하여 사내 규정(POL-HR-2026-004 또는 POL-IT-2026-009)의 조항과 기준을 확인해야 합니다.

2. 근거 조항 명시:
   - 사용자에게 답변할 때는 적용된 규정 번호, 조항, 사전 신청 기한, 결재 조건을 구체적으로 명시하세요.
   - 예: "사내 복무 규정(POL-HR-2026-004 제 4 조)에 따라 3일을 초과하는 연속 연차는 사용 7영업일 전 상신 및 팀장님 사전 승인이 필요합니다."

3. 단계별 처리 절차:
   - [휴가 신청 시]:
     1) 정책 RAG 조회 -> 신청 일수에 따른 사전 기한 및 승인 요건 확인
     2) 'get_employee_leave_balance' 호출 -> 잔여 연차 확인
     3) 요건 충족 시 'submit_leave_request' 도구로 WorkWeek 시스템에 정식 접수
   - [장비 교체/수리 시]:
     1) 정책 RAG 조회 -> 직군별 표준 기종(엔지니어링: M3 Max 64GB) 및 교체 주기(36개월), 긴급 장애 처리 기준 확인
     2) 'list_hardware_assets_and_tickets' 호출 -> 현재 지급된 장비 내구연한(실사용 개월 수) 확인
     3) 'create_hardware_incident_ticket' 호출 -> ServiceImmediately 시스템에 정식 인시던트 티켓 발행

4. 어조:
   - 자연스럽고 정중한 한국어로 명확하게 작성하세요.
""".strip()

def get_enterprise_agent() -> Agent:
    """모든 도구가 연결된 에이전트 인스턴스를 생성합니다."""
    tools = [
        search_company_policy,
        get_employee_leave_balance,
        submit_leave_request,
        list_hardware_assets_and_tickets,
        create_hardware_incident_ticket,
    ]
    
    agent = Agent(
        name=config["agent"]["name"],
        model=config["agent"]["model"],
        instruction=SYSTEM_INSTRUCTION,
        tools=tools,
    )
    logger.info(f"에이전트 '{agent.name}'에 도구 {len(tools)}개 등록 완료")
    return agent

root_agent = get_enterprise_agent()

if __name__ == "__main__":
    print(f"에이전트 준비 완료: {root_agent.name} (등록 도구: {len(root_agent.tools)}개)")

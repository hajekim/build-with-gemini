# enterprise-ops-agent (실습 1 완성본)

Build with Gemini Track 3 실습 1의 결과물입니다. ADK로 만든 멀티 에이전트(오케스트레이터 1개와 워커 3개)가 사내 규정 검색(Vertex AI Search), WorkWeek 인사 시스템과 ServiceImmediately ITSM(둘 다 Mock SaaS의 MCP 서버)을 호출합니다.

이 압축 파일에는 프로젝트 ID, 토큰, 배포 정보가 들어 있지 않습니다. 아래 순서대로 본인 환경 값을 넣으면 그대로 실행됩니다.

## 1. 압축 풀기와 설치

```bash
cd ~
unzip -o enterprise_ops_agent_completed.zip
cd enterprise-ops-agent
agents-cli install
```

`agents-cli install`이 `.venv`를 만들고 의존성을 설치합니다. 이후 명령은 `uv run`으로 실행하거나 `source .venv/bin/activate` 후 실행합니다.

## 2. 본인 환경에 맞게 바꿀 값

코드 안에 본인 값을 적어 넣을 필요는 없습니다. 모두 환경 변수로 읽습니다.

| 환경 변수 | 읽는 위치 | 기본값 | 해야 할 일 |
|:---|:---|:---|:---|
| `GOOGLE_CLOUD_PROJECT` | `app/agent.py`, `app/tools/policy_rag.py` | `gcloud config get-value project` 결과 | `gcloud config set project 내프로젝트ID`를 해 두면 따로 설정하지 않아도 됩니다. |
| `MCP_TOKEN` | `app/tools/mcp_tools.py` | 없음 (필수) | Mock SaaS 웹 화면에서 개인 토큰을 발급해 `export MCP_TOKEN="mcp_..."`로 설정합니다. |
| `POLICY_SEARCH_ENGINE_ID` | `app/tools/policy_rag.py` | `company-policy-app` | 실습 1 Task 1의 6단계로 검색 앱을 같은 이름으로 만들었다면 바꾸지 않습니다. 다른 이름을 썼다면 그 ID를 넣습니다. |
| `KOREAN_MOCK_SAAS_URL` | `app/tools/mcp_tools.py` | 워크숍 공용 Mock SaaS 주소 | 공용 Mock SaaS를 쓰면 그대로 둡니다. 직접 띄운 Mock SaaS가 있으면 그 주소로 바꿉니다. |
| `MODEL_ARMOR_TEMPLATE` | `app/tools/model_armor.py` | 빈 값 (검사 안 함) | 실습 1에서는 비워 둡니다. 실습 2 Step 5에서 템플릿을 만든 뒤 `projects/내프로젝트ID/locations/asia-northeast1/templates/템플릿이름` 형식으로 넣습니다. |
| `A2A_SERVICE_URL` | `a2a_server.py` | `http://localhost:8080` | 로컬 테스트만 한다면 그대로 둡니다. A2A 서버를 외부 주소로 띄울 때 그 주소를 넣으면 에이전트 카드의 `url`에 반영됩니다. |

MCP 토큰은 발급한 브라우저 세션(테넌트)에 묶여 있습니다. 에이전트가 만든 연차 신청이나 티켓을 웹 화면에서 확인하려면 토큰을 발급한 같은 브라우저로 Mock SaaS 화면을 열어야 합니다. 다른 브라우저나 시크릿 창에서는 다른 테넌트의 데이터가 보입니다.

`MCP_TOKEN` 없이 에이전트를 실행하면 연차나 티켓 도구 호출이 실패합니다. ADK가 이 오류를 화면에 드러내지 않아서 "인사팀에 문의하세요" 같은 엉뚱한 답이 나올 수 있으니, 실행 전에 값이 들어 있는지 확인하세요.

```bash
: "${MCP_TOKEN:?MCP_TOKEN을 먼저 export 하세요}"
```

## 3. 규정 검색 앱 준비 (선택이지만 권장)

검색 앱이 없거나 아직 인덱싱 중이면 규정 검색은 `app/tools/policy_rag.py`에 들어 있는 규정 요약으로 동작하는 로컬 폴백(`local_fallback`)을 씁니다. Vertex AI Search 경로까지 쓰려면 실습 1 Task 1의 6단계를 실행합니다. 새 프로젝트라면 그 단계의 첫 명령(`gcloud beta services identity create --service=discoveryengine.googleapis.com`)을 빠뜨리지 마세요. 빠뜨리면 PDF 가져오기가 403으로 실패합니다.

## 4. 동작 확인

```bash
export MCP_TOKEN="mcp_여러분의토큰값"
uv run python3 tests/test_scenarios.py
```

5개 시나리오가 모두 `[PASS]`로 끝나면 준비가 끝난 것입니다. 출력의 `검색 경로`가 `vertex_ai_search`이면 검색 앱까지 연결된 상태이고, `local_fallback`이면 폴백으로 동작한 상태입니다.

대화형으로 확인하려면 다음 중 하나를 씁니다.

```bash
agents-cli run "EMP-10294 직원의 연차 잔여일수 알려줘"   # 한 번 질의
uv run python3 a2a_server.py                              # http://localhost:8080 웹 콘솔과 A2A 엔드포인트
```

## 5. 파일 구성

| 경로 | 내용 |
|:---|:---|
| `app/agent.py` | 오케스트레이터와 워커 3개(hr_policy_agent, workweek_agent, itsm_agent) 정의 |
| `app/tools/policy_rag.py` | Vertex AI Search 규정 검색과 로컬 폴백 |
| `app/tools/mcp_tools.py` | WorkWeek, ServiceImmediately MCP 연결. 요청마다 `X-MCP-Token` 헤더에 `MCP_TOKEN`을 넣음 |
| `app/tools/model_armor.py` | Model Armor 입력 검사 콜백. 템플릿이 비어 있으면 건너뜀 |
| `a2a_server.py`, `agent_manifest.json` | Gemini Enterprise 연동을 위한 A2A 서버와 매니페스트 |
| `tests/test_scenarios.py` | 5개 기본 시나리오 점검 |
| `tests/eval/` | 4-Tier 평가 데이터셋과 `eval_config.yaml` (실습 2 Step 1에서 사용) |
| `docs/SDD.md`, `docs/policies/` | 설계 문서와 규정 원본 PDF |

`.env`, `.venv`, `uv.lock`, `deployment_metadata.json`, 평가 결과(`artifacts/`)는 압축에 넣지 않았습니다. 모두 위 단계를 거치면 본인 환경에서 새로 만들어집니다.

import os
import json
import httpx
from typing import Dict, Any, Optional

from google.adk.tools.mcp_tool import McpToolset
from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams

BASE_URL = os.environ.get("KOREAN_MOCK_SAAS_URL", "https://korean-mock-saas-330751298968.asia-northeast3.run.app")
_CLIENT_CACHE: Optional[httpx.Client] = None
_SESSION_IDS: Dict[str, str] = {}
_MCP_TOKEN: Optional[str] = None

def _get_persistent_client() -> httpx.Client:
    global _CLIENT_CACHE
    if _CLIENT_CACHE is None:
        _CLIENT_CACHE = httpx.Client(timeout=30.0)
    return _CLIENT_CACHE

def _auto_obtain_mcp_token() -> str:
    global _MCP_TOKEN
    if _MCP_TOKEN is not None:
        return _MCP_TOKEN
        
    token = os.environ.get("MCP_TOKEN")
    if token:
        _MCP_TOKEN = token
        return token
        
    client = _get_persistent_client()
    try:
        resp = client.post(
            f"{BASE_URL}/api/mcp-tokens",
            json={"token_name": "workshop-agent"},
            headers={
                "Content-Type": "application/json",
                "X-Session-ID": "sess_auto"
            }
        )
        resp.raise_for_status()
        data = resp.json()
        _MCP_TOKEN = data.get("raw_token")
        if _MCP_TOKEN:
            os.environ["MCP_TOKEN"] = _MCP_TOKEN
            return _MCP_TOKEN
    except Exception as e:
        print(f"Warning: Failed to auto-obtain MCP token: {e}")
    return "mock-token"

def _initialize_mcp_session(client: httpx.Client, endpoint: str) -> str:
    token = _auto_obtain_mcp_token()
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'MCP-Protocol-Version': '2025-06-18',
        'X-MCP-Token': token
    }
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'initialize',
        'params': {
            'protocolVersion': '2025-06-18',
            'capabilities': {},
            'clientInfo': {'name': 'client', 'version': '1.0'}
        }
    }
    resp = client.post(f"{BASE_URL}{endpoint}", json=payload, headers=headers)
    resp.raise_for_status()
    
    session_id = resp.headers.get("mcp-session-id")
    if not session_id:
        session_id = resp.headers.get("Mcp-Session-Id")
        
    return session_id

def _call_mcp_tool(endpoint: str, tool_name: str, arguments: Dict[str, Any]) -> dict:
    client = _get_persistent_client()
    token = _auto_obtain_mcp_token()
    
    global _SESSION_IDS
    if endpoint not in _SESSION_IDS:
        _SESSION_IDS[endpoint] = _initialize_mcp_session(client, endpoint)
        
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'MCP-Protocol-Version': '2025-06-18',
        'X-MCP-Token': token,
        'Mcp-Session-Id': _SESSION_IDS[endpoint]
    }
    
    payload = {
        'jsonrpc': '2.0',
        'id': 2,
        'method': 'tools/call',
        'params': {
            'name': tool_name,
            'arguments': arguments
        }
    }
    
    try:
        resp = client.post(f"{BASE_URL}{endpoint}", json=payload, headers=headers)
        resp.raise_for_status()
        
        # Parse SSE format response
        for line in resp.iter_lines():
            if line.startswith("data: "):
                data_str = line[len("data: "):].strip()
                if data_str:
                    try:
                        data = json.loads(data_str)
                        if "error" in data:
                            return {"status": "ERROR", "error": data["error"]}
                        if "result" in data:
                            return data["result"]
                    except json.JSONDecodeError:
                        continue
        return {}
    except httpx.TimeoutException:
        # Fallback for network timeout as mentioned in SDD
        return {"status": "ERROR", "error": "Network timeout, fallback response activated."}
    except Exception as e:
        return {"status": "ERROR", "error": str(e)}

# 1. Toolsets using Google ADK
def get_workweek_mcp_toolset():
    token = _auto_obtain_mcp_token()
    params = StreamableHTTPConnectionParams(
        url=f"{BASE_URL}/work-week/mcp",
        headers={
            "X-MCP-Token": token
        }
    )
    return McpToolset(connection_params=params)

def get_itsm_mcp_toolset():
    token = _auto_obtain_mcp_token()
    params = StreamableHTTPConnectionParams(
        url=f"{BASE_URL}/service-immediately/mcp",
        headers={
            "X-MCP-Token": token
        }
    )
    return McpToolset(connection_params=params)

# 2. Wrapper Functions
def get_employee_leave_balance(employee_id: str) -> dict:
    return _call_mcp_tool("/work-week/mcp", "get_employee_balances", {"employee_id": employee_id})

def submit_leave_request(employee_id: str, start_date: str, end_date: str, leave_type: str, days: float, reason: str) -> dict:
    return _call_mcp_tool("/work-week/mcp", "request_time_off", {
        "employee_id": employee_id,
        "start_date": start_date,
        "end_date": end_date,
        "leave_type": leave_type,
        "days": days,
        "reason": reason
    })

def cancel_leave_request(employee_id: str, request_id: int) -> dict:
    return _call_mcp_tool("/work-week/mcp", "cancel_leave_request", {
        "employee_id": employee_id,
        "request_id": request_id
    })

def list_hardware_assets_and_tickets(employee_id: str) -> dict:
    return _call_mcp_tool("/service-immediately/mcp", "list_tickets", {"employee_id": employee_id})

def create_hardware_incident_ticket(employee_id: str, title: str, description: str, category: str, priority: str) -> dict:
    return _call_mcp_tool("/service-immediately/mcp", "create_ticket", {
        "requested_by": employee_id,
        "category": category,
        "short_description": title,
        "description": description,
        "priority": priority,
        "assignment_group": "IT Support"
    })

def add_ticket_comment(ticket_id: str, author: str, comment: str) -> dict:
    return _call_mcp_tool("/service-immediately/mcp", "add_ticket_comment", {
        "ticket_id": ticket_id,
        "author": author,
        "comment": comment
    })

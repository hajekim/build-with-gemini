import json

def search_company_policy(query: str, category: str = "ALL") -> dict:
    """사내 복무 규정(POL-HR-2026-004) 및 IT 지원 지침(POL-IT-2026-009)을 검색합니다.
    
    Args:
        query: 검색할 정책 질문 (예: '연차 신청 기한', '노트북 교체 연한', '병가 진단서')
        category: 검색 범위 ('HR', 'IT', 'ALL')
    Returns:
        {
            "status": "SUCCESS",
            "query": query,
            "category": category,
            "match_count": int,
            "grounding_confidence": float (>= 0.90),
            "matches": [
                {"doc_id": str, "title": str, "content": str}
            ]
        }
    """
    hr_policies = [
        {
            "doc_id": "POL-HR-2026-004",
            "title": "제 3 조 (연차 발생 및 부여)",
            "content": "1년 미만 사원은 1개월 개근 시 1.25일 발생(1년 차 총 15일). 3년 이상 근속 시 매 2년마다 1일 가산(최대 25일 한도). 반일(0.5일) 및 전일(1.0일) 단위 분할 사용 가능."
        },
        {
            "doc_id": "POL-HR-2026-004",
            "title": "제 4 조 (신청 및 결재 절차)",
            "content": "모든 휴가는 WorkWeek HRMS로 사전 상신 원칙. 1일 이하: 사용 개시일 24시간 전 상신. 3일 이하: 사용 개시일 3일 전 상신 및 부서장 접수. 3일 초과 연속 연차: 업무 인수인계 및 대행자 지정을 위해 최소 사용 7영업일 전 상신 및 부서장(팀장급 이상) 사전 승인 필수."
        },
        {
            "doc_id": "POL-HR-2026-004",
            "title": "제 5 조 (병가 운영 및 증빙)",
            "content": "연간 최대 14일 유급 병가. 연속 3일 미만은 진료확인서/영수증 제출. 연속 3일 이상은 전문의 진단서를 복귀 후 3영업일 이내 인사팀 제출 필수."
        }
    ]

    it_policies = [
        {
            "doc_id": "POL-IT-2026-009",
            "title": "제 2 조 (전산 장비 지급 기준)",
            "content": "엔지니어링 / 데이터 직군: 고성능 랩톱 (MacBook Pro M3 Max / 64GB RAM 급 또는 동급 모바일 워크스테이션). 기획 / 일반 사무 직군: 표준 랩톱 (MacBook Air / ThinkPad / 16GB RAM 급)."
        },
        {
            "doc_id": "POL-IT-2026-009",
            "title": "제 3 조 (정기 교체 연한 및 요건)",
            "content": "표준 내구연한은 지급일로부터 실사용 36개월(3년) 경과를 원칙으로 함. 36개월 경과 시 신규 표준 기종으로 교체 신청 가능. 기존 장비는 5영업일 내 IT 서비스데스크 반납."
        },
        {
            "doc_id": "POL-IT-2026-009",
            "title": "제 4 조 (장애 발생 및 긴급 교체)",
            "content": "메인보드 고장, 배터리 부풀림(스웰링) 등 중대 결함 발생 시 내구연한과 무관하게 긴급 수리 또는 조기 교체 신청 가능. 접수 후 4근무시간 이내 진단 SLA 및 즉시 수리 불가 시 당일 임시 대여 랩톱 선지급."
        }
    ]

    all_policies = []
    if category in ['HR', 'ALL']:
        all_policies.extend(hr_policies)
    if category in ['IT', 'ALL']:
        all_policies.extend(it_policies)
        
    # A simple keyword-based matching for the mock RAG.
    # We split query into keywords.
    keywords = set(query.replace(",", " ").replace(".", " ").split())
    
    matches = []
    for policy in all_policies:
        # Check if any keyword is in title or content
        score = 0
        for keyword in keywords:
            if len(keyword) > 1 and (keyword in policy['title'] or keyword in policy['content']):
                score += 1
        
        # If no keywords matched, we will still return it if the query is very broad or empty
        if not query or score > 0 or len(keywords) == 0:
            matches.append(policy)
            
    # If standard match fails, fallback to all policies in category
    if not matches:
        matches = all_policies

    return {
        "status": "SUCCESS",
        "query": query,
        "category": category,
        "match_count": len(matches),
        "grounding_confidence": 0.96, # As specified in SDD for fallback: 0.96 (must be >= 0.90)
        "matches": matches
    }

if __name__ == "__main__":
    # Test cases from SDD
    print(json.dumps(search_company_policy("3일 초과 연차", "HR"), indent=2, ensure_ascii=False))
    print(json.dumps(search_company_policy("엔지니어링 M3 Max 64GB 배터리 스웰링", "IT"), indent=2, ensure_ascii=False))

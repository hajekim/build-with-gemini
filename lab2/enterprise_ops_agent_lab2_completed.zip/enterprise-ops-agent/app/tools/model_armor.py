"""Model Armor 런타임 가드 (before_model_callback).

모델 호출 직전, 가장 최근 입력(사용자 메시지 또는 도구 응답)을 Model Armor 템플릿으로 검사해
프롬프트 인젝션/탈옥/민감정보(신용카드 등)가 감지되면 모델 호출을 차단합니다.
MODEL_ARMOR_TEMPLATE 미설정 시 아무것도 하지 않습니다(로컬 개발용).
"""
import json
import os

import google.auth
import google.auth.transport.requests
import httpx
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from google.genai import types

# 예: projects/my-proj/locations/asia-northeast1/templates/hr-agent-armor-template
TEMPLATE = os.environ.get("MODEL_ARMOR_TEMPLATE", "")
TIMEOUT_SEC = 5.0
BLOCK_MESSAGE = ("보안 정책(Model Armor)에 따라 요청을 처리할 수 없습니다. "
                 "프롬프트 인젝션 시도나 신용카드번호 등 민감정보가 감지되었습니다.")


def _latest_text(llm_request: LlmRequest) -> str:
    """가장 최근 content의 텍스트와 도구 응답을 하나의 문자열로 합칩니다."""
    if not llm_request.contents:
        return ""
    chunks = []
    for part in llm_request.contents[-1].parts or []:
        if part.text:
            chunks.append(part.text)
        elif part.function_response:
            chunks.append(json.dumps(part.function_response.response, ensure_ascii=False, default=str))
    return "\n".join(chunks)


def _is_blocked(text: str) -> bool:
    location = TEMPLATE.split("/")[3]
    credentials, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    credentials.refresh(google.auth.transport.requests.Request())
    resp = httpx.post(
        f"https://modelarmor.{location}.rep.googleapis.com/v1/{TEMPLATE}:sanitizeUserPrompt",
        json={"userPromptData": {"text": text}},
        headers={"Authorization": f"Bearer {credentials.token}"},
        timeout=TIMEOUT_SEC,
    )
    resp.raise_for_status()
    return resp.json()["sanitizationResult"]["filterMatchState"] == "MATCH_FOUND"


def armor_guard(callback_context: CallbackContext, llm_request: LlmRequest) -> LlmResponse | None:
    text = _latest_text(llm_request)
    if not TEMPLATE or not text.strip():
        return None
    try:
        blocked = _is_blocked(text)
    except Exception as e:  # 보안 검사 불가 시 통과시키지 않음(fail-closed)
        print(f"[model_armor] 검사 실패, 요청 차단: {e}")
        blocked = True
    if not blocked:
        return None
    print(f"[model_armor] 차단: agent={callback_context.agent_name}")
    return LlmResponse(content=types.Content(role="model", parts=[types.Part(text=BLOCK_MESSAGE)]))

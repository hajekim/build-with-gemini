"""사내 규정 하이브리드 RAG 도구.

1차: Vertex AI Search(GCS에 올린 규정 PDF를 인덱싱한 검색 앱) 검색
2차: Vertex AI Search 미구성/장애 시 PDF에서 발췌한 로컬 조항 인덱스로 폴백
"""
import json
import os

import google.auth
import google.auth.transport.requests
import httpx

SEARCH_ENGINE_ID = os.environ.get("POLICY_SEARCH_ENGINE_ID", "company-policy-app")
SEARCH_LOCATION = "global"  # Vertex AI Search는 global/us/eu 멀티리전만 지원
SEARCH_TIMEOUT_SEC = 10.0
MAX_RESULTS = 3

# PDF 파일명 -> (문서번호, 카테고리)
DOC_MAP = {
    "leave_policy_2026.pdf": ("POL-HR-2026-004", "HR"),
    "it_hardware_guidelines.pdf": ("POL-IT-2026-009", "IT"),
}

# ponytail: 로컬 폴백은 PDF 핵심 조항을 수동 발췌한 고정 인덱스. 규정 개정 시 PDF와 함께 갱신해야 함.
LOCAL_POLICIES = [
    {"doc_id": "POL-HR-2026-004", "category": "HR", "title": "제 3 조 (연차 발생 및 부여)",
     "content": "1년 미만 사원은 1개월 개근 시 1.25일 발생(1년 차 총 15일). 3년 이상 근속 시 매 2년마다 1일 가산(최대 25일 한도). 반일(0.5일) 및 전일(1.0일) 단위 분할 사용 가능."},
    {"doc_id": "POL-HR-2026-004", "category": "HR", "title": "제 4 조 (신청 및 결재 절차)",
     "content": "모든 휴가는 WorkWeek HRMS로 사전 상신 원칙. 1일 이하: 사용 개시일 24시간 전 상신. 3일 이하: 사용 개시일 3일 전 상신 및 부서장 접수. 3일 초과 연속 연차: 업무 인수인계 및 대행자 지정을 위해 최소 사용 7영업일 전 상신 및 부서장(팀장급 이상) 사전 승인 필수."},
    {"doc_id": "POL-HR-2026-004", "category": "HR", "title": "제 5 조 (병가 운영 및 증빙)",
     "content": "연간 최대 14일 유급 병가. 연속 3일 미만은 진료확인서/영수증 제출. 연속 3일 이상은 전문의 진단서를 복귀 후 3영업일 이내 인사팀 제출 필수."},
    {"doc_id": "POL-IT-2026-009", "category": "IT", "title": "제 2 조 (전산 장비 지급 기준)",
     "content": "엔지니어링 / 데이터 직군: 고성능 랩톱 (MacBook Pro M3 Max / 64GB RAM 급 또는 동급 모바일 워크스테이션). 기획 / 일반 사무 직군: 표준 랩톱 (MacBook Air / ThinkPad / 16GB RAM 급)."},
    {"doc_id": "POL-IT-2026-009", "category": "IT", "title": "제 3 조 (정기 교체 연한 및 요건)",
     "content": "표준 내구연한은 지급일로부터 실사용 36개월(3년) 경과를 원칙으로 함. 36개월 경과 시 신규 표준 기종으로 교체 신청 가능. 기존 장비는 5영업일 내 IT 서비스데스크 반납."},
    {"doc_id": "POL-IT-2026-009", "category": "IT", "title": "제 4 조 (장애 발생 및 긴급 교체)",
     "content": "메인보드 고장, 배터리 부풀림(스웰링) 등 중대 결함 발생 시 내구연한과 무관하게 긴급 수리 또는 조기 교체 신청 가능. 접수 후 4근무시간 이내 진단 SLA 및 즉시 수리 불가 시 당일 임시 대여 랩톱 선지급."},
]


def _vertex_search(query: str) -> list[dict]:
    """Vertex AI Search 검색 앱을 호출해 문서별 발췌 세그먼트를 반환합니다."""
    credentials, project = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"])
    project = os.environ.get("GOOGLE_CLOUD_PROJECT", project)
    credentials.refresh(google.auth.transport.requests.Request())
    url = (f"https://discoveryengine.googleapis.com/v1/projects/{project}/locations/{SEARCH_LOCATION}"
           f"/collections/default_collection/engines/{SEARCH_ENGINE_ID}/servingConfigs/default_search:search")
    body = {
        "query": query,
        "pageSize": MAX_RESULTS,
        "contentSearchSpec": {"extractiveContentSpec": {"maxExtractiveSegmentCount": 2}},
    }
    resp = httpx.post(url, json=body, timeout=SEARCH_TIMEOUT_SEC, headers={
        "Authorization": f"Bearer {credentials.token}", "X-Goog-User-Project": project})
    resp.raise_for_status()

    matches = []
    for result in resp.json().get("results", []):
        data = result["document"].get("derivedStructData", {})
        filename = data.get("link", "").rsplit("/", 1)[-1]
        doc_id, category = DOC_MAP.get(filename, (filename, "ALL"))
        for seg in data.get("extractive_segments", []):
            matches.append({"doc_id": doc_id, "category": category, "title": data.get("title", filename),
                            "content": seg.get("content", "").strip()})
    return matches


def _local_search(query: str) -> list[dict]:
    """키워드 겹침으로 로컬 조항 인덱스를 검색합니다."""
    keywords = {k for k in query.replace(",", " ").replace(".", " ").split() if len(k) > 1}
    return [p for p in LOCAL_POLICIES if any(k in p["title"] or k in p["content"] for k in keywords)]


def search_company_policy(query: str, category: str = "ALL") -> dict:
    """사내 복무 규정(POL-HR-2026-004) 및 IT 지원 지침(POL-IT-2026-009)을 검색합니다.

    Args:
        query: 검색할 정책 질문 (예: '연차 신청 기한', '노트북 교체 연한', '병가 진단서')
        category: 검색 범위 ('HR', 'IT', 'ALL')
    Returns:
        status, source('vertex_ai_search' 또는 'local_fallback'), match_count, matches(doc_id, title, content)
    """
    try:
        matches, source = _vertex_search(query), "vertex_ai_search"
    except Exception as e:  # 검색 앱 미구성, 권한, 네트워크 장애 모두 폴백 대상
        print(f"[policy_rag] Vertex AI Search 실패, 로컬 폴백 사용: {e}")
        matches, source = [], "local_fallback"
    if not matches:
        matches, source = _local_search(query), "local_fallback"

    if category != "ALL":
        matches = [m for m in matches if m["category"] in (category, "ALL")]
    if not matches:
        return {"status": "NO_MATCH", "source": source, "query": query, "category": category,
                "match_count": 0, "matches": [],
                "message": "관련 조항을 찾지 못했습니다. 추측하지 말고 인사팀/IT 서비스데스크 확인을 안내하세요."}
    return {"status": "SUCCESS", "source": source, "query": query, "category": category,
            "match_count": len(matches), "matches": matches}


if __name__ == "__main__":
    r1 = search_company_policy("3일 초과 연속 연차 신청 기한", "HR")
    r2 = search_company_policy("배터리 부풀림 긴급 교체", "IT")
    print(json.dumps(r1, indent=2, ensure_ascii=False))
    print(json.dumps(r2, indent=2, ensure_ascii=False))
    assert any("7영업일" in m["content"] for m in r1["matches"]), "HR 조항 미검출"
    assert all(m["doc_id"] == "POL-IT-2026-009" for m in r2["matches"]), "IT 카테고리 필터 실패"
    print("self-check OK, source:", r1["source"], r2["source"])

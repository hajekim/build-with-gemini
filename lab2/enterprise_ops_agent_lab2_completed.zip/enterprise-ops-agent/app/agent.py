import os
from google.adk.agents import Agent
from google.adk.apps import App

# Standardize on Vertex AI global endpoint with gemini-3.8-flash
os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "true")
os.environ.setdefault("GOOGLE_CLOUD_LOCATION", "global")
if "GOOGLE_CLOUD_PROJECT" not in os.environ:
    import subprocess
    try:
        proj = subprocess.check_output(["gcloud", "config", "get-value", "project"], text=True).strip()
        if proj:
            os.environ["GOOGLE_CLOUD_PROJECT"] = proj
    except Exception:
        pass

try:
    from app.tools.policy_rag import search_company_policy
    from app.tools.mcp_tools import get_workweek_mcp_toolset, get_itsm_mcp_toolset
    from app.tools.model_armor import armor_guard
except (ImportError, ModuleNotFoundError):
    try:
        from .tools.policy_rag import search_company_policy
        from .tools.mcp_tools import get_workweek_mcp_toolset, get_itsm_mcp_toolset
        from .tools.model_armor import armor_guard
    except (ImportError, ModuleNotFoundError):
        from tools.policy_rag import search_company_policy
        from tools.mcp_tools import get_workweek_mcp_toolset, get_itsm_mcp_toolset
        from tools.model_armor import armor_guard

HUB_INSTRUCTION = """당신은 Cymbal Group Korea의 엔터프라이즈 AI 운영 에이전트(enterprise_ops_agent)입니다. 
다음 4가지 핵심 거버넌스 행동 수칙을 강력하게 반영하여 업무를 수행하십시오:

1. [규정 우선 원칙]: 시스템에 휴가 신청이나 티켓을 발행하기 전에 반드시 'hr_policy_agent'를 먼저 호출하여 사전 적합성을 검증할 것.
2. [근거 명시]: POL-HR-2026-004 또는 POL-IT-2026-009의 조항 번호와 사전 신청 기한, 승인 요건을 최종 답변에 반드시 포함할 것.
3. [단계별 검증]: 규정에 부합할 때만 workweek_agent 또는 itsm_agent를 호출하여 SaaS 작업을 진행할 것.
4. [친절하고 명확한 한국어 톤]: 전문적이고 정중한 한국어 톤을 유지하여 응답할 것.
"""

MODEL_NAME = "gemini-3.8-flash"

def build_agent() -> Agent:
    hr_policy_agent = Agent(
        name="hr_policy_agent",
        model=MODEL_NAME,
        before_model_callback=armor_guard,  # MODEL_ARMOR_TEMPLATE 설정 시 활성화
        instruction="사내 복무 및 IT 지원 지침(POL-HR-2026-004, POL-IT-2026-009) 선검증 전담 에이전트입니다. 맡은 작업을 마치면 답변을 끝내지 말고 transfer_to_agent로 enterprise_ops_agent에 제어를 돌려주세요.",
        tools=[search_company_policy]
    )

    workweek_agent = Agent(
        name="workweek_agent",
        model=MODEL_NAME,
        before_model_callback=armor_guard,  # MODEL_ARMOR_TEMPLATE 설정 시 활성화
        instruction="연차 조회, 휴가 상신/취소 전담 WorkWeek HRMS 에이전트입니다. 맡은 작업을 마치면 답변을 끝내지 말고 transfer_to_agent로 enterprise_ops_agent에 제어를 돌려주세요.",
        tools=[get_workweek_mcp_toolset()]
    )

    itsm_agent = Agent(
        name="itsm_agent",
        model=MODEL_NAME,
        before_model_callback=armor_guard,  # MODEL_ARMOR_TEMPLATE 설정 시 활성화
        instruction="장비 조회, 결함 티켓 생성 전담 ServiceImmediately ITMS 에이전트입니다. 맡은 작업을 마치면 답변을 끝내지 말고 transfer_to_agent로 enterprise_ops_agent에 제어를 돌려주세요.",
        tools=[get_itsm_mcp_toolset()]
    )

    root_agent = Agent(
        name="enterprise_ops_agent",
        model=MODEL_NAME,
        before_model_callback=armor_guard,  # MODEL_ARMOR_TEMPLATE 설정 시 활성화
        instruction=HUB_INSTRUCTION,
        sub_agents=[hr_policy_agent, workweek_agent, itsm_agent]
    )

    return root_agent

def get_enterprise_agent() -> Agent:
    return build_agent()

root_agent = build_agent()
app = App(root_agent=root_agent, name="app")

if __name__ == "__main__":
    print(f"멀티 에이전트 준비 완료: {root_agent.name} (model: {MODEL_NAME}) / 서브 에이전트: {[sa.name for sa in root_agent.sub_agents]}")

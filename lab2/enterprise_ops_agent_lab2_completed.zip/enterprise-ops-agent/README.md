# enterprise-ops-agent (실습 2 완성본)

Build with Gemini Track 3 실습 2의 결과물입니다. 실습 1 에이전트를 Agent Runtime 배포용으로 전환(`agents-cli scaffold enhance`)하고, Agent Gateway 루트 인증서를 신뢰하도록 Dockerfile을 바꾼 상태입니다. 이 폴더에서 바로 `agents-cli deploy`를 실행할 수 있습니다.

프로젝트 ID, 토큰, 엔진 ID, 게이트웨이 인증서는 들어 있지 않습니다. 이 값들은 본인 프로젝트에서 새로 만들어 넣어야 합니다. 4.6의 프롬프트 힐클라이밍 결과도 들어 있지 않습니다. 에이전트 지시문은 실습 1 완성본과 같습니다.

## 1. 압축 풀기와 설치

```bash
cd ~
unzip -o enterprise_ops_agent_lab2_completed.zip
cd enterprise-ops-agent
agents-cli install
```

실습 1 폴더(`~/enterprise-ops-agent`)가 이미 있으면 덮어씁니다. 기존 폴더를 남기려면 다른 위치에서 압축을 푸세요.

## 2. 본인 환경에 맞게 바꿀 값

### 환경 변수 (코드가 읽는 값)

| 환경 변수 | 로컬 실행 | 배포본 |
|:---|:---|:---|
| `GOOGLE_CLOUD_PROJECT` | `gcloud config set project 내프로젝트ID`로 자동 설정 | Agent Runtime이 자동으로 설정 |
| `MCP_TOKEN` | Mock SaaS 웹 화면에서 발급한 토큰을 `export MCP_TOKEN="mcp_..."` | Secret Manager 시크릿을 `--secrets`로 주입 (아래 3단계) |
| `POLICY_SEARCH_ENGINE_ID` | 기본값 `company-policy-app`. 다른 이름으로 검색 앱을 만들었을 때만 설정 | 필요하면 `--update-env-vars`로 전달 |
| `KOREAN_MOCK_SAAS_URL` | 기본값은 워크숍 공용 Mock SaaS. 직접 띄운 Mock SaaS가 있을 때만 설정 | 필요하면 `--update-env-vars`로 전달 |
| `MODEL_ARMOR_TEMPLATE` | 비워 두면 검사하지 않음 | 실습 2 Step 5에서 `projects/내프로젝트ID/locations/asia-northeast1/templates/hr-agent-armor-template` 형식으로 전달 |

MCP 토큰은 발급한 브라우저 세션(테넌트)에 묶여 있습니다. 에이전트가 만든 신청이나 티켓은 토큰을 발급한 같은 브라우저의 Mock SaaS 화면에서만 보입니다.

### 파일과 명령 인자

| 대상 | 기본값 | 바꿀 때 |
|:---|:---|:---|
| 배포 리전 (`--region`) | `asia-northeast1` | Agent Gateway가 있는 리전과 같아야 합니다. 서울(`asia-northeast3`)은 게이트웨이를 지원하지 않습니다. |
| 시크릿 이름 (`--secrets`) | `enterprise-agent-mcp-token` | 다른 이름으로 시크릿을 만들었다면 `MCP_TOKEN=시크릿이름:latest`로 바꿉니다. |
| 빌드 인자 `AGENT_GATEWAY_ROOT_CERTIFICATES` | 없음 | 본인 게이트웨이의 루트 인증서(`agw_root.pem`)를 넣습니다. 게이트웨이마다 인증서가 다르므로 다른 사람의 파일을 쓰면 안 됩니다. 값을 비우면 Dockerfile의 인증서 단계는 건너뜁니다(게이트웨이 없이 배포할 때). |
| `agents-cli-manifest.yaml`의 `name` | `enterprise-ops-agent` | Agent Runtime 엔진 표시 이름입니다. 엔진을 새로 만들어야 할 때(실습 2 10.1의 시크릿 오류) 이름을 바꿉니다. |
| `deployment/terraform/single-project/vars/env.tfvars` | `your-gcp-project-id` | 실습에서는 쓰지 않습니다. Terraform으로 인프라를 만들 때만 프로젝트 ID와 리전을 넣습니다. |

`deployment_metadata.json`은 넣지 않았습니다. 그래서 첫 배포는 본인 프로젝트에 새 엔진을 만들고, 이 파일에 엔진 ID를 기록합니다. 엔진이 바뀌면 실습 2 7.3의 게이트웨이 연결도 새 엔진으로 다시 설정해야 합니다.

## 3. 배포 순서

실습 2 문서의 명령을 그대로 쓰면 됩니다. 순서만 정리하면 다음과 같습니다.

1. 2.3: 필요한 API 활성화
2. 5.4: 시크릿 생성과 권한 부여. 새 프로젝트에서는 빈 엔진을 만들었다 지우는 단계가 들어 있으니 건너뛰지 마세요. 빠뜨리면 배포가 `secret_env` 오류로 실패합니다.
3. 5.5: Agent Gateway 생성과 `~/lab2/agw_root.pem` 저장
4. 5.8: 배포와 질의 확인 (5.3과 5.6은 이 압축에 이미 반영되어 있으므로 건너뜁니다)

```bash
CERT=$(awk '{printf "%s\\n", $0}' ~/lab2/agw_root.pem)
agents-cli deploy -d agent_runtime \
  --project=${PROJECT_ID} --region=asia-northeast1 \
  --agent-identity --no-confirm-project \
  --secrets="MCP_TOKEN=enterprise-agent-mcp-token:latest" \
  --update-env-vars="GOOGLE_API_PREVENT_AGENT_TOKEN_SHARING_FOR_GCP_SERVICES=false" \
  --build-args="AGENT_GATEWAY_ROOT_CERTIFICATES=${CERT}"
```

이후 Agent Registry(6.4), 게이트웨이 정책(7.5~7.7), Model Armor(8.4), Gemini Enterprise 등록(9.3)은 실습 2 문서 순서대로 진행합니다.

## 4. 로컬에서 먼저 확인하기

```bash
export MCP_TOKEN="mcp_여러분의토큰값"
uv run python3 tests/test_scenarios.py
```

5개 시나리오가 모두 `[PASS]`면 코드와 토큰은 정상입니다. 평가를 다시 돌리려면 실습 2 4.4의 명령을 그대로 실행합니다.

## 5. 실습 1 완성본과 다른 파일

| 경로 | 내용 |
|:---|:---|
| `Dockerfile` | 게이트웨이 루트 인증서를 시스템 저장소와 venv의 certifi 번들에 추가 |
| `agents-cli-manifest.yaml` | 배포 대상이 `agent_runtime`으로 바뀜 |
| `app/app_utils/reasoning_engine_adapter.py`, `app/fast_api_app.py`, `pyproject.toml` | enhance가 추가하거나 수정한 Agent Runtime 실행 코드 |
| `deployment/terraform/` | enhance가 만든 Terraform 템플릿 (실습에서는 사용하지 않음) |
| `tests/unit/`, `tests/integration/`, `tests/eval/response_quality.py` | enhance가 만든 기본 테스트 |
| `.env.example`, `.gitignore`, `GEMINI.md` | enhance가 만든 설정 예시와 agy용 프로젝트 안내 |

`.venv`, `uv.lock`, `.agents/skills`(실습 2 3.1에서 내려받음), 평가 결과(`artifacts/`), 게이트웨이 인증서 파일은 압축에 넣지 않았습니다.

"""Gemini Enterprise A2A 규격 호환 서빙 서버 (Live ADK Runner)."""

import asyncio
import json
import logging
import os
import uuid
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import uvicorn

from app.agent import root_agent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("a2a_server")

os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
os.environ["GOOGLE_CLOUD_LOCATION"] = os.getenv("GOOGLE_CLOUD_LOCATION", "global")

app = FastAPI(title="Enterprise Ops Agent - A2A Gateway", version="1.0.0")

session_service = InMemorySessionService()
runner = Runner(agent=root_agent, session_service=session_service, app_name="enterprise_ops_app")

AGENT_CARD = {
    "name": "Cymbal Enterprise Ops Agent",
    "description": "사내 복무 지침(POL-HR-2026-004) 및 IT 자산 지침(POL-IT-2026-009)을 준수하여 휴가 신청 및 하드웨어 인시던트를 처리하는 엔터프라이즈 운영 에이전트",
    "version": "1.0.0",
    "protocolVersion": "0.3.0",
    "preferredTransport": "JSONRPC",
    "capabilities": {
        "streaming": False,
    },
    "defaultInputModes": ["text", "text/plain"],
    "defaultOutputModes": ["text", "text/plain"],
    "skills": [
        {
            "id": "hr_leave_management",
            "name": "HR Leave Management",
            "description": "사내 복무 지침을 조회하고 잔여 연차를 확인하여 WorkWeek 시스템에 휴가를 신청합니다.",
            "examples": [
                "다음 주 월요일부터 4일 연속 연차 신청해줘",
                "내 연차 잔여 일수 조회해줘",
            ],
            "tags": ["hr", "leave", "timeoff", "policy"],
        },
        {
            "id": "it_hardware_support",
            "name": "IT Hardware Support",
            "description": "사내 IT 하드웨어 규정을 조회하고 장비 결함 시 ServiceImmediately 시스템에 인시던트 티켓을 발행합니다.",
            "examples": [
                "노트북 배터리가 부풀어 올랐는데 M3 Max 64GB로 교체해줘",
                "내 장비 지급 이력 확인해줘",
                "IT 티켓이 총 몇개인가요?",
            ],
            "tags": ["it", "hardware", "incident", "ticket"],
        },
    ],
    "url": os.getenv("A2A_SERVICE_URL", "http://localhost:8080"),
}


@app.get("/healthz")
async def healthz():
  return {"status": "ok", "agent": "enterprise-ops-agent", "version": "1.0.0"}


@app.get("/.well-known/agent-card.json")
@app.get("/a2a/app/.well-known/agent-card.json")
async def get_agent_card():
  return AGENT_CARD


class ChatRequest(BaseModel):
  message: str
  user_id: str = "EMP-10294"


LOCAL_HTML_UI = """<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cymbal Enterprise Ops Agent - 로컬 테스트 콘솔</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@400;500;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Pretendard', sans-serif; }
    .mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 min-h-screen flex flex-col items-center p-3 md:p-6">
  <div class="w-full max-w-4xl bg-white rounded-2xl shadow-xl border border-slate-200 flex flex-col h-[92vh] overflow-hidden">
    <!-- Header -->
    <header class="bg-white border-b border-slate-200 px-6 py-3.5 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center text-xl shadow-md">
          <i class="fa-solid fa-robot"></i>
        </div>
        <div>
          <h1 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Cymbal Enterprise Ops Agent</span>
            <span class="text-[11px] bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded-full mono">Local Runner</span>
          </h1>
          <p class="text-xs text-slate-500">Google ADK 2.0 & Vertex AI Gemini 3.8 Flash (사내 RAG & Mock SaaS 연동)</p>
        </div>
      </div>
      <div class="flex items-center gap-2 text-xs">
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
          <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Active
        </span>
      </div>
    </header>

    <!-- Chat Messages Container -->
    <div id="chat-box" class="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/60">
      <!-- Welcome message -->
      <div class="flex gap-3 max-w-2xl">
        <div class="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm shadow-xs">
          <i class="fa-solid fa-robot"></i>
        </div>
        <div class="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-xs text-xs text-slate-800 leading-relaxed space-y-2">
          <p class="font-bold text-slate-900">안녕하세요! Cymbal Enterprise IT/HR 운영 에이전트입니다.</p>
          <p>사내 복무 지침(POL-HR-2026-004) 및 IT 자산 지침(POL-IT-2026-009)을 준수하여 휴가 신청 및 하드웨어 인시던트 티켓을 처리합니다. 아래 추천 질문 칩을 클릭하거나 직접 메시지를 입력하세요.</p>
        </div>
      </div>

      <!-- Turn 1: User -->
      <div class="flex justify-end">
        <div class="bg-blue-600 text-white p-3.5 rounded-2xl rounded-tr-none text-xs leading-relaxed max-w-xl shadow-xs">
          내 잔여 연차와 병가 일수 알려줘
        </div>
      </div>

      <!-- Turn 1: Agent -->
      <div class="flex gap-3 max-w-2xl">
        <div class="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm shadow-xs">
          <i class="fa-solid fa-robot"></i>
        </div>
        <div class="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-xs text-xs text-slate-800 leading-relaxed space-y-2">
          <p class="font-bold text-slate-900">이민우 님(사번: EMP-10294)의 현재 휴가 잔여 현황입니다.</p>
          <ul class="list-disc pl-4 space-y-1 text-slate-700">
            <li><strong>총 발생 연차:</strong> 15일</li>
            <li><strong>사용 및 대기 연차:</strong> 13일</li>
            <li><strong>잔여 연차:</strong> <span class="font-bold text-blue-600">2.0일</span></li>
            <li><strong>잔여 병가:</strong> <span class="font-bold text-emerald-600">14.0일</span></li>
          </ul>
          <p class="text-[11px] text-slate-500 pt-1">근거 규정: 사내 복무 지침 (POL-HR-2026-004 제 3 조) / WorkWeek 연동 확인</p>
        </div>
      </div>

      <!-- Turn 2: User -->
      <div class="flex justify-end">
        <div class="bg-blue-600 text-white p-3.5 rounded-2xl rounded-tr-none text-xs leading-relaxed max-w-xl shadow-xs">
          현재 내 오픈된 IT 지원 티켓 목록 확인해줘
        </div>
      </div>

      <!-- Turn 2: Agent -->
      <div class="flex gap-3 max-w-2xl">
        <div class="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm shadow-xs">
          <i class="fa-solid fa-robot"></i>
        </div>
        <div class="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-xs text-xs text-slate-800 leading-relaxed space-y-2">
          <p class="font-bold text-slate-900">ServiceImmediately 시스템 조회 결과, 등록된 활성 티켓은 총 3건입니다.</p>
          <div class="space-y-1.5 text-[11px] text-slate-700">
            <div class="p-2 bg-slate-50 rounded-lg border border-slate-200">
              <span class="font-bold text-blue-700">1. INC-88210:</span> 업무용 M3 Max 랩톱 교체 신청 <span class="text-amber-600 font-semibold">(처리중 - 이번 주 목요일 사내 지급 예정)</span>
            </div>
            <div class="p-2 bg-slate-50 rounded-lg border border-slate-200">
              <span class="font-bold text-blue-700">2. INC-88211:</span> 원격 근무용 보안 VPN 접속 권한 갱신 <span class="text-blue-600 font-semibold">(접수)</span>
            </div>
            <div class="p-2 bg-slate-50 rounded-lg border border-slate-200">
              <span class="font-bold text-blue-700">3. INC-88300:</span> Test monitor issue <span class="text-slate-600 font-semibold">(접수)</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Suggested Prompts Chips -->
    <div class="px-6 py-2.5 bg-slate-100/80 border-t border-slate-200 overflow-x-auto flex gap-2 no-scrollbar">
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">내 잔여 연차와 병가 일수 알려줘</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">회사 휴가 규정 및 발생 기준이 어떻게 돼?</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">업무용 노트북 및 IT 장비 교체 규정 알려줘</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">2026-11-20에 연차 1일 신청해줘</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">현재 내 오픈된 IT 지원 티켓 목록 확인해줘</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">모니터 화면이 깜빡거려. 하드웨어 점검 티켓 등록해줘</button>
      <button onclick="sendQuick(this.innerText)" class="chip px-3 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-300 text-xs font-medium whitespace-nowrap transition shadow-2xs">내 남은 연차랑 현재 접수된 랩톱 교체 티켓 상태 둘 다 확인해줘</button>
    </div>

    <!-- Input Footer -->
    <footer class="p-4 bg-white border-t border-slate-200">
      <form id="chat-form" onsubmit="handleSend(event)" class="flex gap-2">
        <input type="text" id="user-input" placeholder="질문을 입력하세요... (예: 사내 복무 규정상 병가 기준은?)" class="flex-1 border border-slate-300 rounded-xl px-4 py-3 text-xs focus:outline-hidden focus:border-blue-600 focus:ring-2 focus:ring-blue-100" autocomplete="off" />
        <button type="submit" id="btn-submit" class="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5">
          <span>전송</span>
          <i class="fa-solid fa-paper-plane"></i>
        </button>
      </form>
    </footer>
  </div>

  <script>
    async function handleSend(e) {
      if (e) e.preventDefault();
      const input = document.getElementById("user-input");
      const text = input.value.trim();
      if (!text) return;
      input.value = "";
      appendMessage("user", text);
      const loadingId = appendLoading();
      try {
        const resp = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: text, user_id: "EMP-10294" })
        });
        const data = await resp.json();
        removeLoading(loadingId);
        appendMessage("agent", data.reply);
      } catch (err) {
        removeLoading(loadingId);
        appendMessage("agent", "오류가 발생했습니다: " + err.message);
      }
    }
    function sendQuick(txt) {
      document.getElementById("user-input").value = txt;
      handleSend();
    }
    function appendMessage(role, text) {
      const box = document.getElementById("chat-box");
      const div = document.createElement("div");
      if (role === "user") {
        div.className = "flex justify-end";
        div.innerHTML = `<div class="bg-blue-600 text-white p-3.5 rounded-2xl rounded-tr-none text-xs leading-relaxed max-w-xl shadow-xs whitespace-pre-wrap">${text}</div>`;
      } else {
        div.className = "flex gap-3 max-w-2xl";
        div.innerHTML = `<div class="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm shadow-xs"><i class="fa-solid fa-robot"></i></div>
          <div class="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-xs text-xs text-slate-800 leading-relaxed whitespace-pre-wrap">${text}</div>`;
      }
      box.appendChild(div);
      box.scrollTop = box.scrollHeight;
    }
    function appendLoading() {
      const id = "loading-" + Date.now();
      const box = document.getElementById("chat-box");
      const div = document.createElement("div");
      div.id = id;
      div.className = "flex gap-3 max-w-2xl";
      div.innerHTML = `<div class="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 text-sm shadow-xs"><i class="fa-solid fa-robot"></i></div>
        <div class="bg-white p-3 rounded-2xl rounded-tl-none border border-slate-200 shadow-xs text-xs text-slate-500 flex items-center gap-2">
          <i class="fa-solid fa-circle-notch fa-spin text-blue-600"></i>
          <span>에이전트가 생각하고 도구를 호출하고 있습니다...</span>
        </div>`;
      box.appendChild(div);
      box.scrollTop = box.scrollHeight;
      return id;
    }
    function removeLoading(id) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }
  </script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def local_web_app():
  return HTMLResponse(content=LOCAL_HTML_UI)


@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
  reply = await run_agent_live(user_id=req.user_id, message=req.message)
  return {"reply": reply, "status": "SUCCESS"}


async def run_agent_live(user_id: str, message: str) -> str:
  """ADK Runner와 Gemini 3.8 Flash를 통한 지능형 에이전트 실행."""
  try:
    session = await session_service.create_session(
        user_id=user_id, app_name="enterprise_ops_app"
    )
    msg = types.Content(
        role="user", parts=[types.Part.from_text(text=message)]
    )

    full_response = ""
    async for event in runner.run_async(
        user_id=user_id, session_id=session.id, new_message=msg
    ):
      if event.content and event.content.parts:
        for part in event.content.parts:
          if part.text:
            full_response += part.text

    if not full_response.strip():
      full_response = "Cymbal Enterprise 운영 에이전트입니다. 요청을 처리하였습니다."
    return full_response
  except Exception as e:
    logger.exception(f"Agent execution error: {e}")
    return f"에이전트 실행 중 오류가 발생했습니다: {str(e)}"


# JSON-RPC A2A handler for Gemini Enterprise
@app.post("/")
@app.post("/a2a/app")
async def json_rpc_handler(request: Request):
  data = await request.json()
  method = data.get("method", "message/send")
  req_id = data.get("id", 1)
  logger.info(f"Incoming A2A JSON-RPC method={method}, id={req_id}")

  if method == "agent/card":
    return {"jsonrpc": "2.0", "id": req_id, "result": AGENT_CARD}

  params = data.get("params", {})
  user_text = ""
  context_id = f"ctx-{uuid.uuid4().hex[:8]}"

  if isinstance(params, dict):
    if "contextId" in params:
      context_id = params["contextId"]
    elif "context_id" in params:
      context_id = params["context_id"]

    msg_obj = params.get("message", {})
    if isinstance(msg_obj, dict):
      if "contextId" in msg_obj:
        context_id = msg_obj["contextId"]
      parts = msg_obj.get("parts", [])
      if isinstance(parts, list):
        for p in parts:
          if isinstance(p, dict) and "text" in p:
            user_text += p["text"] + " "
      elif isinstance(msg_obj.get("text"), str):
        user_text = msg_obj["text"]

    if not user_text and "input" in params:
      inp = params["input"]
      if isinstance(inp, dict):
        user_text = inp.get("text", "")
      elif isinstance(inp, list) and len(inp) > 0:
        user_text = inp[0].get("text", "")
      elif isinstance(inp, str):
        user_text = inp

  if not user_text.strip():
    user_text = "안녕하세요"

  logger.info(f"User query received from GE: '{user_text.strip()}'")

  # Run real Gemini reasoning and tool calling!
  reply_text = await run_agent_live("EMP-10294", user_text.strip())

  msg_id = f"msg-{uuid.uuid4().hex[:10]}"
  message_result = {
      "kind": "message",
      "messageId": msg_id,
      "contextId": context_id,
      "role": "agent",
      "parts": [
          {
              "kind": "text",
              "text": reply_text,
          }
      ],
  }

  logger.info(f"Returning A2A SendMessageSuccessResponse: msg_id={msg_id}")
  return {
      "jsonrpc": "2.0",
      "id": req_id,
      "result": message_result,
  }


if __name__ == "__main__":
  port = int(os.getenv("PORT", "8080"))
  uvicorn.run("a2a_server:app", host="0.0.0.0", port=port, reload=False)
